package com.ssadak.biz.userInfo.impl;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ssadak.biz.userInfo.UserInfoVO;

@Repository
public class UserInfoDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	private String USER_INSERT = "insert into user(id,pw,age,sex,phone,email,nickname) values(?,?,?,?,?,?,?)";
	private String USER_UPDATE = "update user set pw=?,email=?,nickname=?";
	private String USER_DELETE = "delete user where id=?";
	private String USER_INFO = "SELECT * from user where id=? AND pw=?";
	private String USER_FIND_ID = "SELECT * from user where phone=? AND email=?";
	private String USER_FIND_PW = "SELECT * from user where id=?";
	
	
	
	public void insertUser(UserInfoVO vo) {
		jdbcTemplate.update(USER_INSERT,vo.getId(),vo.getPw(),vo.getAge(),vo.getSex(),vo.getPhone(),vo.getEmail(),vo.getNickname());
	}
	public void updateUser(UserInfoVO vo) {
		jdbcTemplate.update(USER_UPDATE,vo.getPw(),vo.getEmail(),vo.getNickname());
	}
	public void deleteUser(UserInfoVO vo) {
		jdbcTemplate.update(USER_DELETE,vo.getId());
	}
	public UserInfoVO infoUser(UserInfoVO vo) {
		
		
		return jdbcTemplate.queryForObject(USER_INFO, new Object[]{vo.getId(), vo.getPw()}, new UserRowMapper());
	   
	}
	public UserInfoVO findId(UserInfoVO vo) {
		
		return jdbcTemplate.queryForObject(USER_FIND_ID, new Object[]{vo.getPhone(), vo.getEmail()}, new UserRowMapper());
	}
	public UserInfoVO findPw(UserInfoVO vo) {
		return jdbcTemplate.queryForObject(USER_FIND_PW, new Object[]{vo.getId()}, new UserRowMapper());
	}
	

	
}

