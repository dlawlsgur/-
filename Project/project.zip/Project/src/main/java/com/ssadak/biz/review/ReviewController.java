package com.ssadak.biz.review;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ReviewController {

	
	@Autowired
	private ReviewService reService;
	
	@RequestMapping("review.do")
	public String review(Model model) {
		model.addAttribute("list",reService.getList());
		return "review.jsp";
	}
	
}
