package com.ssadak.biz.review;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.ssadak.biz.reviewInfo.ReviewInfoVO;
import org.springframework.jdbc.core.RowMapper;

public class ReviewRowMapper implements RowMapper<ReviewInfoVO> {

	public ArrayList<ReviewInfoVO> mapRow(ResultSet rs,int rwNum) throws SQLException{
		
		ReviewInfoVO vo = new ReviewInfoVO();
		ArrayList<ReviewInfoVO> list =  new ArrayList<ReviewInfoVO>();
		while(rs.next()) {
		
			vo.setTitle(rs.getString("title"));
			vo.setName(rs.getString("name"));
			vo.setwTime(rs.getString("wTime"));
			vo.setWriting(rs.getString("writing"));
			vo.setCountNum(rs.getInt("countNum"));
			vo.setGroupNum(rs.getInt("groupNum"));
			vo.setIndentNum(rs.getInt("indentNum"));
			list.add(vo);
		}
		return list;
	}
	
}
