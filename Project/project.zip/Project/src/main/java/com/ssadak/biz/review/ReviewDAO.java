package com.ssadak.biz.review;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.ssadak.biz.reviewInfo.ReviewInfoVO;
import java.util.ArrayList;




@Repository
public class ReviewDAO {

	@Autowired 
	private JdbcTemplate jdbcTemplate;
	
	private String REVIEW_INSERT = "insert into review(id,nickname,title,writing,wTime,countNum,gropuNum,indentNum) values(?,?,?,?,?,?,?,?)";
	private String REVIEW_UPDATE = "update review set pw=?,email=?,nickname=?";
	private String REVIEW_DELETE = "delete review where id=?";
	private String REVIEW_LIST = "SELECT * from list";
	private String REVIEW_INFO = "SELECT * from user where phone=? AND email=?";

	public ArrayList<ReviewInfoVO> getList() {
		
		return jdbcTemplate.query(REVIEW_LIST,new ReviewRowMapper());
	}
	public void insertReview(ReviewInfoVO vo) {
		jdbcTemplate.update(REVIEW_INSERT,vo.getId(),vo.getNickname(),vo.getTitle(),vo.getWriting(),vo.getwTime(),vo.getCountNum(),vo.getGroupNum(),vo.getIndentNum()); 
	}
	public void updateReview(ReviewInfoVO vo) {
		jdbcTemplate.update(REVIEW_DELETE,vo.getId());
	}
	public void deleteReview(ReviewInfoVO vo) {
		jdbcTemplate.update(REVIEW_DELETE,vo.getId());
	}
	public ArrayList<ReviewInfoVO> infoReview(ReviewInfoVO vo) {
		
		return jdbcTemplate.queryForObject(REVIEW_LIST,new Object[] {vo.getGroupNum()},new ReviewRowMapper());
	}
	
}
