package com.ssadak.biz.review;

import java.util.ArrayList;

import com.ssadak.biz.reviewInfo.ReviewInfoVO;

public interface ReviewService {
	
	public ArrayList<ReviewInfoVO> getList();
	public void insertReview(ReviewInfoVO vo);
	public void updateReview(ReviewInfoVO vo);
	public void deleteReview(ReviewInfoVO vo);
	public ArrayList<ReviewInfoVO> infoReview(ReviewInfoVO vo);
	
	
	
}
