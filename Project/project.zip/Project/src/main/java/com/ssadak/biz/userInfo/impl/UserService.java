package com.ssadak.biz.userInfo.impl;

import com.ssadak.biz.userInfo.UserInfoVO;

public interface UserService {

	
	 void insertUser(UserInfoVO vo);
	 void updaretUser(UserInfoVO vo);
	 void deletetUser(UserInfoVO vo);
	 UserInfoVO infoUser(UserInfoVO vo);
	 UserInfoVO findId(UserInfoVO vo);
	 UserInfoVO findPw(UserInfoVO vo);
	 
	
}
